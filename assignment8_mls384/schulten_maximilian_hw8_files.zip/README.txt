3 Modules are in use:
    numpy -- Used for arithmetic and other menial tasks
    matplotlib -- Used to plot the data points
    pandas -- Used to read in and manipulate CSV

Plots prior to final exercise are in plot.py and plotPosterior.py.
All files can be run using 'python3 *.py' and in order to make changes to the parameters please examine
the call to the main method at the end of the file.

Exercise 5 is found in k-means-cluster.py.
