2 Modules are in use:
    numpy -- Used for arithmetic and other menial tasks
    matplotlib -- Used to plot the data points

All relevant programming exercises are in plot.py.
The file can be run using 'python3 plot.py' and in order to make changes to the parameters please examine
the call to the main method at the end of the file. Probabilities must sum to 1 and, naturally, need to all have the same length.

To select the trueBag simply pass in the key it is referenced by in the bags dictionary.
